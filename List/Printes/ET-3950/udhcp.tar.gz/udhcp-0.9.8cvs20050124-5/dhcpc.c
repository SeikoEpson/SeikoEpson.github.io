/* dhcpc.c
 *
 * udhcp DHCP client
 *
 * Russ Dill <Russ.Dill@asu.edu> July 2001
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <sys/time.h>
#include <sys/file.h>
#include <unistd.h>
#include <getopt.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <signal.h>
#include <time.h>
#include <string.h>
#include <sys/ioctl.h>
#include <net/if.h>
#include <errno.h>

#include "dhcpd.h"
#include "dhcpc.h"
#include "options.h"
#include "clientpacket.h"
#include "clientsocket.h"
#include "script.h"
#include "socket.h"
#include "common.h"
#include "signalpipe.h"

static int state;
static unsigned long requested_ip; /* = 0 */
static unsigned long server_addr;
static unsigned long timeout;
static int packet_num; /* = 0 */
static int fd = -1;
#ifdef	ENABLE_FEATURE_BOOTP
typedef enum {
	BOOTP_INIT=0,
	BOOTP_BOOTREPLY_RECEIVED,
	BOOTP_BOUNDED,
} client_bootp_state;
#endif	// ENABLE_FEATURE_BOOTP

#define LISTEN_NONE 0
#define LISTEN_KERNEL 1
#define LISTEN_RAW 2
static int listen_mode;

struct client_config_t client_config = {
	/* Default options. */
	abort_if_no_lease: 0,
	foreground: 0,
	quit_after_lease: 0,
	background_if_no_lease: 0,
	interface: "eth0",
	pidfile: NULL,
	script: DEFAULT_SCRIPT,
	clientid: NULL,
	hostname: NULL,
	fqdn: NULL,
	ifindex: 0,
	arp: "\0\0\0\0\0\0",		/* appease gcc-3.0 */
#ifdef	ENABLE_FEATURE_BOOTP
	bootp: 0,
#endif	// ENABLE_FEATURE_BOOTP
	use_server_hostname: 0,
	use_server_domainname: 0,
};

#ifndef IN_BUSYBOX
static void __attribute__ ((noreturn)) show_usage(void)
{
	printf(
"Usage: udhcpc [OPTIONS]\n\n"
#ifdef	ENABLE_FEATURE_BOOTP
"  -B, --bootp                     Enable both DHCP and BOOTP\n"
#endif	// ENABLE_FEATURE_BOOTP
"  -c, --clientid=CLIENTID         Client identifier\n"
"  -t, --use_server_hostname       Use hostname given by server\n"
"  -u, --use_server_domainname     Use domainname given by server\n"
"  -H, --hostname=HOSTNAME         Client hostname\n"
"  -h                              Alias for -H\n"
"  -F, --fqdn=FQDN                 Client fully qualified domain name\n"
"  -f, --foreground                Do not fork after getting lease\n"
"  -b, --background                Fork to background if lease cannot be\n"
"                                  immediately negotiated.\n"
"  -i, --interface=INTERFACE       Interface to use (default: eth0)\n"
"  -n, --now                       Exit with failure if lease cannot be\n"
"                                  immediately negotiated.\n"
"  -p, --pidfile=file              Store process ID of daemon in file\n"
"  -q, --quit                      Quit after obtaining lease\n"
"  -r, --request=IP                IP address to request (default: none)\n"
"  -s, --script=file               Run file at dhcp events (default:\n"
"                                  " DEFAULT_SCRIPT ")\n"
"  -v, --version                   Display version\n"
	);
	exit(0);
}
#else
#define show_usage bb_show_usage
extern void show_usage(void) __attribute__ ((noreturn));
#endif


/* just a little helper */
static void change_mode(int new_mode)
{
	DEBUG(LOG_INFO, "entering %s listen mode",
		new_mode ? (new_mode == 1 ? "kernel" : "raw") : "none");
	if (fd >= 0) close(fd);
	fd = -1;
	listen_mode = new_mode;
}


/* perform a renew */
static void perform_renew(void)
{
	LOG(LOG_INFO, "Performing a DHCP renew");
	switch (state) {
	case BOUND:
		change_mode(LISTEN_KERNEL);
	case RENEWING:
	case REBINDING:
		state = RENEW_REQUESTED;
		break;
	case RENEW_REQUESTED: /* impatient are we? fine, square 1 */
		run_script(NULL, "deconfig");
	case REQUESTING:
	case RELEASED:
		change_mode(LISTEN_RAW);
		state = INIT_SELECTING;
		break;
	case INIT_SELECTING:
		break;
	}

	/* start things over */
	packet_num = 0;

	/* Kill any timeouts because the user wants this to hurry along */
	timeout = 0;
}


/* perform a release */
static void perform_release(void)
{
	char buffer[16];
	struct in_addr temp_addr;

	/* send release packet */
	if (state == BOUND || state == RENEWING || state == REBINDING) {
		temp_addr.s_addr = server_addr;
		sprintf(buffer, "%s", inet_ntoa(temp_addr));
		temp_addr.s_addr = requested_ip;
		LOG(LOG_INFO, "Unicasting a release of %s to %s",
				inet_ntoa(temp_addr), buffer);
		send_release(server_addr, requested_ip); /* unicast */
		run_script(NULL, "deconfig");
	}
	LOG(LOG_INFO, "Entering released state");

	change_mode(LISTEN_NONE);
	state = RELEASED;
	timeout = 0x7fffffff;
}


static void client_background(void)
{
	background(client_config.pidfile);
	client_config.foreground = 1; /* Do not fork again. */
	client_config.background_if_no_lease = 0;
}

/* 2007/02/05 Added to check validity */
/* 
	Check an subnet mask is valid or not 
	Parameter:
		subnet_mask: Subnet mask
	Return result:
		1: Valid
		0: Invalid
*/
static int is_valid_subnetmask(unsigned long subnet_mask)
{
	unsigned long wildcard = ~htonl(subnet_mask);

	/* Subnet mask is 0.0.0.0 - invalid */
	if (subnet_mask == 0)
		return 0;
	/* Check subnet_mask is valid or not */
	while (wildcard % 2 == 1 && wildcard > 1)
	{
		wildcard = wildcard / 2;
	}
	
	return (wildcard == 1);
}

/* 
	Get natural subnet mask
	Parameter:
		ip_addr: IP address
		subnet_mask: Subnet mask
	Return result:
		1: Success
		0: Failed
*/
static int get_natural_subnetmask(unsigned long ip_addr, unsigned long* subnet_mask)
{
	int first_network_number = (htonl(ip_addr) & 0xFF000000) >> 24;

	if (first_network_number >= 1 && first_network_number <= 126) /* Class A */
	{
		*subnet_mask = htonl(0xFF000000);
	}
	else if (first_network_number >= 128 && first_network_number <= 191) /* Class B */
	{
		*subnet_mask = htonl(0xFFFF0000);
	}
	else if (first_network_number >= 192 && first_network_number <= 223) /* Class C */
	{
		*subnet_mask = htonl(0xFFFFFF00);
	}
	else /* invalid ip */
	{
		return 0;
	}
	
	return 1;
}

/* 
	Check an IP address is valid or not 
	Parameter:
		ip_addr: IP address
		subnet_mask: Subnet mask
	Return result:
		1: Valid
		0: Invalid
*/
static int is_valid_ipaddr(unsigned long ip_addr, unsigned long subnet_mask)
{
	unsigned long wildcard = 0;
	unsigned long temp = 0;

	/* Check subnet_mask is valid or not */
	if (is_valid_subnetmask(subnet_mask) == 0)
		return 0;
	
	/* Check ip addr is valid or not */
	wildcard = ~htonl(subnet_mask);
	temp = (htonl(ip_addr) & wildcard);
	if (temp == 0x00000000 || temp == wildcard) /* invalid ip addr */
		return 0;
	
	return 1;
}

/*
	Create FQDN field information
	Parameter:
		fqdn: FQDN name
		len: length of FQDN
	Return result:
		Pointer to fqdn field.
*/
static uint8_t *create_fqdnfield(char* fqdn, int len) {
	uint8_t * retptr = NULL;
	
	retptr = xmalloc(len + 5);
	retptr[OPT_CODE] = DHCP_FQDN;
	retptr[OPT_LEN] = len + 3;
	/* Flags: 0000NEOS
	S: 1 => Client requests Server to update A RR in DNS as well as PTR
	O: 1 => Server indicates to client that DNS has been updated regardless
	E: 1 => Name data is DNS format, i.e. <4>host<6>domain<4>com<0> not "host.domain.com"
	N: 1 => Client requests Server to not update DNS
	*/
	retptr[OPT_LEN + 1] = 0x1;
	retptr[OPT_LEN + 2] = 0;
	retptr[OPT_LEN + 3] = 0;
	strncpy(retptr + 5, fqdn, len);
	
	return retptr;
}

#define MIN_HOST_NAME_LEN		2
#define MAX_HOST_NAME_LEN		15
#define MIN_DOMAIN_NAME_LEN		2
#define MAX_DOMAIN_NAME_LEN		249
#define MAX_FQDN_LEN			252

/*
	Check a host name is valid or not
	Parameter:
		host_name: host name
		len: length of host name
	Return result:
		1: Valid
		0: Invalid
*/
static int check_host_name(const uint8_t *host_name, int len)
{
	int i;

	if ((len < MIN_HOST_NAME_LEN) || (MAX_HOST_NAME_LEN < len)) {
		return 0;
	}
	for (i = 0; i < len; i++) {
		if (('A' <= host_name[i]) && (host_name[i] <= 'Z')) {
			/* 'A'-'Z' are valid */
		} else if (('a' <= host_name[i]) && (host_name[i] <= 'z')) {
			/* 'a'-'z' are valid */
		} else if (host_name[i] == '-') {
			/* '-' is invalid for first or last character */
			if ((i == 0) || (i == len - 1)) {
				return 0;
			}
		} else if (('0' <= host_name[i]) && (host_name[i] <= '9')) {
			/* '0'-'9' are invalid for first character */
			if (i == 0) {
				return 0;
			}
		} else {
			/* invalid */
			return 0;
		}
	}
	return 1;
}

/*
	Check a domain name is valid or not
	Parameter:
		domain_name: domain name
		len: length of domain name
	Return result:
		1: Valid
		0: Invalid
*/
static int check_domain_name(const uint8_t *domain_name, int len)
{
	int i;
	int num;

	if ((len < MIN_DOMAIN_NAME_LEN) || (MAX_DOMAIN_NAME_LEN < len)) {
		return 0;
	}
	for (i = 0; i < len; i++) {
		if (('A' <= domain_name[i]) && (domain_name[i] <= 'Z')) {
			/* 'A'-'Z' are valid */
		} else if (('a' <= domain_name[i]) && (domain_name[i] <= 'z')) {
			/* 'a'-'z' are valid */
		} else if ((domain_name[i] == '-') || (domain_name[i] == '.')) {
			/* '-' and '.' are invaild for first or last character */
			if ((i == 0) || (i == len - 1)) {
				return 0;
			}
		} else if (('0' <= domain_name[i]) && (domain_name[i] <= '9')) {
			/* '0'-'9' are invalid for first character */
			if (i == 0) {
				return 0;
			}
		} else {
			/* invalid */
			return 0;
		}
	}
	/* each label length must be 1 to 63 characters */
	num = 0;
	for (i = 0; i < len; i++) {
		if (domain_name[i] != '.') {
			num++;
			if (num > 63) {
				return 0;
			}
		} else {
			if (num > 0) {
				num = 0;
			} else {
				/* empty label */
				return 0;
			}
		}
	}
	return 1;
}


#ifdef COMBINED_BINARY
int udhcpc_main(int argc, char *argv[])
#else
int main(int argc, char *argv[])
#endif
{
	uint8_t *temp, *message;
	unsigned long t1 = 0, t2 = 0, xid = 0;
	unsigned long start = 0, lease;
	fd_set rfds;
	int retval;
	struct timeval tv;
	int c, len;
	struct dhcpMessage packet;
#ifdef	ENABLE_FEATURE_BOOTP
	// To keep BOOTP information
	struct dhcpMessage bootreply_packet;
	client_bootp_state bootp_state = BOOTP_INIT;
	unsigned long bootp_xid = 0;
#endif	// ENABLE_FEATURE_BOOTP
	struct in_addr temp_addr;
	long now;
	int max_fd;
	int sig;
	/* 2007/02/05 Changed to check validity */
	unsigned long temp_server_addr = 0;
	unsigned long subnet_mask = 0xFFFFFFFF;

	static const struct option arg_options[] = {
		{"clientid",	required_argument,	0, 'c'},
		{"foreground",	no_argument,		0, 'f'},
		{"background",	no_argument,		0, 'b'},
		{"hostname",	required_argument,	0, 'H'},
		{"hostname",	required_argument,	0, 'h'},
		{"fqdn",	required_argument,	0, 'F'},
		{"interface",	required_argument,	0, 'i'},
		{"now", 	no_argument,		0, 'n'},
		{"pidfile",	required_argument,	0, 'p'},
		{"quit",	no_argument,		0, 'q'},
		{"request",	required_argument,	0, 'r'},
		{"script",	required_argument,	0, 's'},
		{"version",	no_argument,		0, 'v'},
#ifdef	ENABLE_FEATURE_BOOTP
		{"bootp",	no_argument,		0,	'B'},
#endif	// ENABLE_FEATURE_BOOTP
		{"use_server_hostname",			no_argument,	0,	't'},
		{"use_server_domainname",		no_argument,	0,	'u'},
		{0, 0, 0, 0}
	};

#ifdef	ENABLE_FEATURE_BOOTP
	static const char* optstring = "c:fbH:h:F:i:np:qr:s:vBtu";
#else	// ENABLE_FEATURE_BOOTP
	static const char* optstring = "c:fbH:h:F:i:np:qr:s:vtu";
#endif	// ENABLE_FEATURE_BOOTP

	/* get options */
	while (1) {
		int option_index = 0;
		c = getopt_long(argc, argv, optstring, arg_options, &option_index);
		if (c == -1) break;

		switch (c) {
		case 'c':
			len = strlen(optarg) > 255 ? 255 : strlen(optarg);
			if (client_config.clientid) free(client_config.clientid);
			client_config.clientid = xmalloc(len + 2);
			client_config.clientid[OPT_CODE] = DHCP_CLIENT_ID;
			client_config.clientid[OPT_LEN] = len;
			client_config.clientid[OPT_DATA] = '\0';
			strncpy(client_config.clientid + OPT_DATA, optarg, len);
			break;
		case 'f':
			client_config.foreground = 1;
			break;
		case 'b':
			client_config.background_if_no_lease = 1;
			break;
		case 'h':
		case 'H':
			len = strlen(optarg) > 255 ? 255 : strlen(optarg);
			if (client_config.hostname) free(client_config.hostname);
			client_config.hostname = xmalloc(len + 2);
			client_config.hostname[OPT_CODE] = DHCP_HOST_NAME;
			client_config.hostname[OPT_LEN] = len;
			strncpy(client_config.hostname + 2, optarg, len);
			break;
		case 'F':
			len = strlen(optarg) > 255 ? 255 : strlen(optarg);
			if (client_config.fqdn) {
				free(client_config.fqdn);
				client_config.fqdn = NULL;
			}
			client_config.fqdn = create_fqdnfield(optarg, len);
			break;
		case 'i':
			client_config.interface =  optarg;
			break;
		case 'n':
			client_config.abort_if_no_lease = 1;
			break;
		case 'p':
			client_config.pidfile = optarg;
			break;
		case 'q':
			client_config.quit_after_lease = 1;
			break;
		case 'r':
			requested_ip = inet_addr(optarg);
			break;
		case 's':
			client_config.script = optarg;
			break;
		case 'v':
			printf("udhcpcd, version %s\n\n", VERSION);
			return 0;
			break;
#ifdef	ENABLE_FEATURE_BOOTP
		case 'B':
			client_config.bootp = 1;
			break;
#endif	// ENABLE_FEATURE_BOOTP
		case 't':
			client_config.use_server_hostname = 1;
			break;
		case 'u':
			client_config.use_server_domainname = 1;
			break;
		default:
			show_usage();
		}
	}

	/* Start the log, sanitize fd's, and write a pid file */
	start_log_and_pid("udhcpc", client_config.pidfile);

	if (read_interface(client_config.interface, &client_config.ifindex,
			   NULL, client_config.arp) < 0)
		return 1;

	if (!client_config.clientid) {
		client_config.clientid = xmalloc(6 + 3);
		client_config.clientid[OPT_CODE] = DHCP_CLIENT_ID;
		client_config.clientid[OPT_LEN] = 7;
		client_config.clientid[OPT_DATA] = 1;
		memcpy(client_config.clientid + 3, client_config.arp, 6);
	}

	/* setup the signal pipe */
	udhcp_sp_setup();

	state = INIT_SELECTING;
	run_script(NULL, "deconfig");
	change_mode(LISTEN_RAW);

	for (;;) {

		tv.tv_sec = timeout - uptime();
		tv.tv_usec = 0;

		if (listen_mode != LISTEN_NONE && fd < 0) {
			if (listen_mode == LISTEN_KERNEL)
				fd = listen_socket(INADDR_ANY, CLIENT_PORT, client_config.interface);
			else
				fd = raw_socket(client_config.ifindex);
			if (fd < 0) {
				LOG(LOG_ERR, "FATAL: couldn't listen on socket, %m");
				return 0;
			}
		}
		max_fd = udhcp_sp_fd_set(&rfds, fd);

		if (tv.tv_sec > 0) {
			DEBUG(LOG_INFO, "Waiting on select...");
			retval = select(max_fd + 1, &rfds, NULL, NULL, &tv);
		} else retval = 0; /* If we already timed out, fall through */

		now = uptime();
		if (retval == 0) {
			/* timeout dropped to zero */
			switch (state) {
			case INIT_SELECTING:
				if (packet_num < 3) {
#ifdef	ENABLE_FEATURE_BOOTP
					if (packet_num == 0) {
						xid = random_xid();
						if (client_config.bootp && bootp_state != BOOTP_BOUNDED) {
							bootp_xid = random_xid();
							bootp_state = BOOTP_INIT;
						}
					}
#else	// ENABLE_FEATURE_BOOTP
					if (packet_num == 0)
						xid = random_xid();
#endif	// ENABLE_FEATURE_BOOTP

					/* send discover packet */
					send_discover(xid, requested_ip); /* broadcast */
#ifdef	ENABLE_FEATURE_BOOTP
					if (client_config.bootp && bootp_state == BOOTP_INIT) {
						send_bootrequest(bootp_xid); /* broadcast */
					}
#endif	// ENABLE_FEATURE_BOOTP

					timeout = now + ((packet_num == 2) ? 4 : 2);
					packet_num++;
				} else {
#ifdef	ENABLE_FEATURE_BOOTP
					if (client_config.bootp && bootp_state == BOOTP_BOOTREPLY_RECEIVED) {
						run_script(&bootreply_packet, "bootpbound");
						bootp_state = BOOTP_BOUNDED;
					} else {
						run_script(NULL, "leasefail");
					}
#else	// ENABLE_FEATURE_BOOTP
					run_script(NULL, "leasefail");
#endif	// ENABLE_FEATURE_BOOTP
					if (client_config.background_if_no_lease) {
						LOG(LOG_INFO, "No lease, forking to background.");
						client_background();
					} else if (client_config.abort_if_no_lease) {
						LOG(LOG_INFO, "No lease, failing.");
						return 1;
				  	}
					/* wait to try again */
					packet_num = 0;
					timeout = now + 60;
				}
				break;
			case RENEW_REQUESTED:
			case REQUESTING:
#if 1 /* two more retries for reliability */
				if (packet_num < 5) {
#else
				if (packet_num < 3) {
#endif
					/* send request packet */
					if (state == RENEW_REQUESTED)
						send_renew(xid, server_addr, requested_ip); /* unicast */
					else send_selecting(xid, server_addr, requested_ip); /* broadcast */

#if 1 /* two more retries for reliability */
					timeout = now + ((packet_num == 4) ? 10 : 2);
#else
					timeout = now + ((packet_num == 2) ? 10 : 2);
#endif
					packet_num++;
				} else {
					/* timed out, go back to init state */
					if (state == RENEW_REQUESTED) run_script(NULL, "deconfig");
					state = INIT_SELECTING;
					timeout = now;
					packet_num = 0;
					change_mode(LISTEN_RAW);
				}
				break;
			case BOUND:
				/* Lease is starting to run out, time to enter renewing state */
				state = RENEWING;
				change_mode(LISTEN_KERNEL);
				DEBUG(LOG_INFO, "Entering renew state");
				/* fall right through */
			case RENEWING:
				/* Either set a new T1, or enter REBINDING state */
				if ((t2 - t1) <= (lease / 14400 + 1)) {
					/* timed out, enter rebinding state */
					state = REBINDING;
					timeout = now + (t2 - t1);
					DEBUG(LOG_INFO, "Entering rebinding state");
				} else {
					/* send a request packet */
					send_renew(xid, server_addr, requested_ip); /* unicast */

					t1 = (t2 - t1) / 2 + t1;
					timeout = t1 + start;
				}
				break;
			case REBINDING:
				/* Either set a new T2, or enter INIT state */
				if ((lease - t2) <= (lease / 14400 + 1)) {
					/* timed out, enter init state */
					state = INIT_SELECTING;
					LOG(LOG_INFO, "Lease lost, entering init state");
					run_script(NULL, "deconfig");
					timeout = now;
					packet_num = 0;
					change_mode(LISTEN_RAW);
				} else {
					/* send a request packet */
					send_renew(xid, 0, requested_ip); /* broadcast */

					t2 = (lease - t2) / 2 + t2;
					timeout = t2 + start;
				}
				break;
			case RELEASED:
				/* yah, I know, *you* say it would never happen */
				timeout = 0x7fffffff;
				break;
			}
		} else if (retval > 0 && listen_mode != LISTEN_NONE && FD_ISSET(fd, &rfds)) {
			/* a packet is ready, read it */

			if (listen_mode == LISTEN_KERNEL)
				len = get_packet(&packet, fd);
			else len = get_raw_packet(&packet, fd);

			if (len == -1 && errno != EINTR) {
				DEBUG(LOG_INFO, "error on read, %m, reopening socket");
				change_mode(listen_mode); /* just close and reopen */
			}
			if (len < 0) continue;

			if (packet.xid != xid) {
#ifdef	ENABLE_FEATURE_BOOTP
				if (!client_config.bootp || packet.xid != bootp_xid) {
					DEBUG(LOG_INFO, "Ignoring XID %lx (our xid is %lx and %lx)",
						(unsigned long) packet.xid, xid, bootp_xid);
					continue;
				}
#else	// ENABLE_FEATURE_BOOTP
				DEBUG(LOG_INFO, "Ignoring XID %lx (our xid is %lx)",
					(unsigned long) packet.xid, xid);
				continue;
#endif	// ENABLE_FEATURE_BOOTP
			}

			if ((message = get_option(&packet, DHCP_MESSAGE_TYPE)) == NULL) {
#ifdef	ENABLE_FEATURE_BOOTP
				if (client_config.bootp) {
					DEBUG(LOG_INFO, "probably recieved a BOOTREPLY packet.");
				} else {
					DEBUG(LOG_ERR, "couldnt get option from packet -- ignoring");
					continue;
				}
#else	// ENABLE_FEATURE_BOOTP
				DEBUG(LOG_ERR, "couldnt get option from packet -- ignoring");
				continue;
#endif	// ENABLE_FEATURE_BOOTP
			}

			switch (state) {
			case INIT_SELECTING:
				/* Must be a DHCPOFFER to one of our xid's */
#ifdef	ENABLE_FEATURE_BOOTP
				if (message != NULL && *message == DHCPOFFER) {
#else	// ENABLE_FEATURE_BOOTP
				if (*message == DHCPOFFER) {
#endif	// ENABLE_FEATURE_BOOTP
					if ((temp = get_option(&packet, DHCP_SERVER_ID))) {
						memcpy(&server_addr, temp, 4);

						/* 2007/02/05 Added to check validity */
						if ((temp = get_option(&packet, DHCP_SUBNET)))
						{
							memcpy(&subnet_mask, temp, 4);
						}
						else if (get_natural_subnetmask(packet.yiaddr, &subnet_mask) == 0)
						{
							break; /* discard packet */
						}
						if (is_valid_ipaddr(packet.yiaddr, subnet_mask) == 0)/* invalid */
						{
							break; /* discard packet */
						}
						if (get_natural_subnetmask(server_addr, &subnet_mask) == 0)
						{
							break; /* discard packet */
						}
						if (is_valid_ipaddr(server_addr, subnet_mask) == 0)/* invalid */
						{
							break; /* discard packet */
						}
						
						xid = packet.xid;
						requested_ip = packet.yiaddr;

						/* enter requesting state */
						state = REQUESTING;
						timeout = now;
						packet_num = 0;

						/* use server information about host name and domain name, if required */
						if (client_config.use_server_hostname || client_config.use_server_domainname) {
							uint8_t *server_host = NULL;
							uint8_t *server_domain = NULL;
							uint8_t *default_host = NULL;
							uint8_t *default_domain = NULL;
							int server_host_len = 0;
							int server_domain_len = 0;
							int default_host_len = 0;
							int default_domain_len = 0;

							DEBUG(LOG_INFO, "use server information");

							/* get host name given by server */
							if (client_config.use_server_hostname) {
								server_host = get_option(&packet, DHCP_HOST_NAME);
								if (server_host != NULL) {
									for (server_host_len = 0; server_host_len < server_host[OPT_LEN - OPT_DATA]; server_host_len++) {
										if (server_host[server_host_len] == 0) {
											break;
										}
									}
									if (check_host_name(server_host, server_host_len)) {
										DEBUG(LOG_INFO, "host name from server is valid (\"%.*s\", len=%d)", server_host_len, server_host, server_host_len);
									} else {
										DEBUG(LOG_INFO, "host name from server is invalid (\"%.*s\", len=%d)", server_host_len, server_host, server_host_len);
										server_host = NULL;
										server_host_len = 0;
									}
								} else {
									DEBUG(LOG_INFO, "host name from server is not given");
								}
							}

							/* get default host name from option */
							if (client_config.hostname) {
								default_host = client_config.hostname + OPT_DATA;
								default_host_len = client_config.hostname[OPT_LEN];
								DEBUG(LOG_INFO, "default host name is valid (%.*s)", default_host_len, default_host);
							}

							/* get domain name given by server */
							if (client_config.use_server_domainname) {
								server_domain = get_option(&packet, DHCP_DOMAIN_NAME);
								if (server_domain != NULL) {
									for (server_domain_len = 0; server_domain_len < server_domain[OPT_LEN - OPT_DATA]; server_domain_len++) {
										if (server_domain[server_domain_len] == 0) {
											break;
										}
									}
									if (check_domain_name(server_domain, server_domain_len)) {
										DEBUG(LOG_INFO, "domain name from server is valid (\"%.*s\", len=%d)", server_domain_len, server_domain, server_domain_len);
									} else {
										DEBUG(LOG_INFO, "domain name from server is invalid (\"%.*s\", len=%d)", server_domain_len, server_domain, server_domain_len);
										server_domain = NULL;
										server_domain_len = 0;
									}
								} else {
									DEBUG(LOG_INFO, "domain name from server is not given");
								}
							}

							/* get default domain name from option */
							if (client_config.fqdn) {
								/* get domain name from fqdn */
								default_domain = client_config.fqdn + OPT_DATA + 3;
								default_domain_len = client_config.fqdn[OPT_LEN] - 3;
								while (default_domain_len > 0) {
									if (*default_domain == '.') {
										default_domain++;
										default_domain_len--;
										break;
									}
									default_domain++;
									default_domain_len--;
								}
								if (default_domain_len > 0) {
									DEBUG(LOG_INFO, "default domain name is valid (%.*s)", default_domain_len, default_domain);
								} else {
									default_domain = NULL;
									DEBUG(LOG_INFO, "default domain name is not valid");
								}
							}

							/* check FQDN length */
							if (client_config.use_server_hostname && (!client_config.use_server_domainname)) {
								/* use host name given by server, if FQDN length is right */
								if ((server_host != NULL) && ((server_host_len + default_domain_len) <= (MAX_FQDN_LEN - 1))) {
									default_host = server_host;
									default_host_len = server_host_len;
									DEBUG(LOG_INFO, "use host name from server");
								} else {
									DEBUG(LOG_INFO, "use default host name");
								}
							} else if ((!client_config.use_server_hostname) && client_config.use_server_domainname) {
								/* use domain name given by server, if FQDN length is right */
								if ((server_domain != NULL) && ((default_host_len + server_domain_len) <= (MAX_FQDN_LEN - 1))) {
									default_domain = server_domain;
									default_domain_len = server_domain_len;
									DEBUG(LOG_INFO, "use domain name from server");
								} else {
									DEBUG(LOG_INFO, "use default domain name");
								}
							} else {
								/* use host name and domain name given by server, if FQDN length is right */
								if ((server_host != NULL) && (server_domain != NULL) && ((server_host_len + server_domain_len) <= (MAX_FQDN_LEN - 1))) {
									default_host = server_host;
									default_host_len = server_host_len;
									default_domain = server_domain;
									default_domain_len = server_domain_len;
									DEBUG(LOG_INFO, "use host name and domain name from server");
								} else {
									DEBUG(LOG_INFO, "use default host name and domain name");
								}
							}

							/* replace host name, if required */
							if (client_config.use_server_hostname && (default_host != NULL) && (default_host == server_host)) {
								if (client_config.hostname) {
									free(client_config.hostname);
									client_config.hostname = xmalloc(default_host_len + OPT_DATA);
									client_config.hostname[OPT_CODE] = DHCP_HOST_NAME;
									client_config.hostname[OPT_LEN] = default_host_len;
									strncpy(client_config.hostname + OPT_DATA, default_host, default_host_len);
									DEBUG(LOG_INFO, "host name replaced (%.*s)", default_host_len, default_host);
								}
							}

							/* make FQDN, if required */
							if (client_config.fqdn) {
								if ((default_host != NULL) && (default_domain != NULL)) {
									uint8_t *fqdn_buf;
									int fqdn_len;

									fqdn_len = default_host_len  + default_domain_len + 1/* . */;
									fqdn_buf = xmalloc(fqdn_len);
									memcpy(fqdn_buf, default_host, (size_t)default_host_len);
									fqdn_buf[default_host_len] = '.';
									memcpy(&fqdn_buf[default_host_len + 1], default_domain, (size_t)default_domain_len);
									DEBUG(LOG_INFO, "FQDN is valid (%.*s)", fqdn_len, fqdn_buf);
									free(client_config.fqdn);
									client_config.fqdn = create_fqdnfield(fqdn_buf, fqdn_len);
									free(fqdn_buf);
								} else {
									DEBUG(LOG_ERR, "FQDN is invalid");
									free(client_config.fqdn);
									client_config.fqdn = NULL;
								}
							}

							client_config.use_server_hostname = 0;
							client_config.use_server_domainname = 0;
						}
					} else {
						DEBUG(LOG_ERR, "No server ID in message");
					}
#ifdef	ENABLE_FEATURE_BOOTP
				} else if ((message == NULL) && client_config.bootp && (bootp_state == BOOTP_INIT)) {
					DEBUG(LOG_INFO, "remain BOOTP information.");
					if (packet.xid != bootp_xid) {
						DEBUG(LOG_INFO, "probably reply of a DHCP Discover packet.");
						break; /* discard packet */
					}
					if ((temp = get_option(&packet, DHCP_SUBNET))) {
						memcpy(&subnet_mask, temp, 4);
					} else if (get_natural_subnetmask(packet.yiaddr, &subnet_mask) == 0) {
						DEBUG(LOG_ERR, "Invalid client address (Unable to get natural subnet mask)");
						break; /* discard packet */
					}
					if (is_valid_ipaddr(packet.yiaddr, subnet_mask) == 0) { /* invalid */
						DEBUG(LOG_ERR, "Invalid client address");
						break; /* discard packet */
					}
					if (get_natural_subnetmask(packet.siaddr, &subnet_mask) == 0) {
						DEBUG(LOG_ERR, "Invalid server address");
						break; /* discard packet */
					}

					/* bootreply_packet is not NULL from now to timeout of DHCPDISCOVER. */
					bootreply_packet = packet;
					bootp_state = BOOTP_BOOTREPLY_RECEIVED;
#endif	// ENABLE_FEATURE_BOOTP
				}
				break;
			case RENEW_REQUESTED:
			case REQUESTING:
			case RENEWING:
			case REBINDING:
#ifdef	ENABLE_FEATURE_BOOTP
				if (message == NULL) {
					// Ignore all BOOTREPLY packets.
					DEBUG(LOG_INFO, "Ignore all BOOTREPLY packets.\n");
					break;
				}
#endif	// ENABLE_FEATURE_BOOTP
				/* 2007/02/05 Added for fix DHCP Problems */
				if (state == REQUESTING && (*message == DHCPACK || *message == DHCPNAK))
				{
					/* Check Server Identifier */
					if ((temp = get_option(&packet, DHCP_SERVER_ID))) 
					{
						memcpy(&temp_server_addr, temp, 4);
						if (temp_server_addr != server_addr)
							break;/* ignore mismatch packet */
						else if (*message == DHCPACK)
						{
							if (requested_ip != packet.yiaddr)
							{
								break;/* ignore mismatch packet */
							}
						}
					}
					else 
					{
						DEBUG(LOG_ERR, "No server ID in message");
						break;
					}
				}
					
				if (*message == DHCPACK) {
					if (!(temp = get_option(&packet, DHCP_LEASE_TIME))) {
						LOG(LOG_ERR, "No lease time with ACK, using 1 hour lease");
						lease = 60 * 60;
					} else {
						memcpy(&lease, temp, 4);
						lease = ntohl(lease);
					}

					/* enter bound state */
					t1 = lease / 2;

					/* little fixed point for n * .875 */
					t2 = (lease * 0x7) >> 3;
					temp_addr.s_addr = packet.yiaddr;
					LOG(LOG_INFO, "Lease of %s obtained, lease time %ld",
						inet_ntoa(temp_addr), lease);
					start = now;
					timeout = t1 + start;
					requested_ip = packet.yiaddr;
					run_script(&packet,
						   ((state == RENEWING || state == REBINDING) ? "renew" : "bound"));

					state = BOUND;
					change_mode(LISTEN_NONE);
					if (client_config.quit_after_lease)
						return 0;
					if (!client_config.foreground)
						client_background();

				} else if (*message == DHCPNAK) {
					/* return to init state */
					LOG(LOG_INFO, "Received DHCP NAK");
					run_script(&packet, "nak");
					if (state != REQUESTING)
						run_script(NULL, "deconfig");
					state = INIT_SELECTING;
					timeout = now;
					requested_ip = 0;
					packet_num = 0;
					change_mode(LISTEN_RAW);
					sleep(3); /* avoid excessive network traffic */
				}
				break;
			/* case BOUND, RELEASED: - ignore all packets */
			}
		} else if (retval > 0 && (sig = udhcp_sp_read(&rfds))) {
			switch (sig) {
			case SIGUSR1:
				perform_renew();
				break;
			case SIGUSR2:
				perform_release();
				break;
			case SIGTERM:
				LOG(LOG_INFO, "Received SIGTERM");
				return 0;
			}
		} else if (retval == -1 && errno == EINTR) {
			/* a signal was caught */
		} else {
			/* An error occured */
			DEBUG(LOG_ERR, "Error on select");
		}

	}
	return 0;
}
