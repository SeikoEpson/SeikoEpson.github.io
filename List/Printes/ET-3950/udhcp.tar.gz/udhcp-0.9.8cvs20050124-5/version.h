#ifndef _UDHCP_VERSION_H
#define _UDHCP_VERSION_H

#define VERSION "1.0.1"

#endif
