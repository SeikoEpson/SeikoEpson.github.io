#ifndef _PACKET_H
#define _PACKET_H

#include <netinet/udp.h>
#include <netinet/ip.h>

#define DHCP_ORG_MESSAGE_DATA_SIZE			308 /* 312 - cookie */

#ifdef EXPAND_RECEIVE_MESSAGE_SIZE
	#define DHCP_EXP_MESSAGE_DATA_SIZE	512 /* expand for receive from windows server */
#else /* EXPAND_RECEIVE_MESSAGE_SIZE */
	#define DHCP_EXP_MESSAGE_DATA_SIZE	DHCP_ORG_MESSAGE_DATA_SIZE
#endif /* EXPAND_RECEIVE_MESSAGE_SIZE */

#define UDP_DHCP_SEND_PACKET_SIZE	(sizeof(struct udp_dhcp_packet_org))
#define UDP_DHCP_SEND_MESSAGE_SIZE	(sizeof(struct dhcpMessageOrg))

struct dhcpMessageOrg {
	uint8_t op;
	uint8_t htype;
	uint8_t hlen;
	uint8_t hops;
	uint32_t xid;
	uint16_t secs;
	uint16_t flags;
	uint32_t ciaddr;
	uint32_t yiaddr;
	uint32_t siaddr;
	uint32_t giaddr;
	uint8_t chaddr[16];
	uint8_t sname[64];
	uint8_t file[128];
	uint32_t cookie;
	uint8_t options[DHCP_ORG_MESSAGE_DATA_SIZE];
};

struct dhcpMessage {
	uint8_t op;
	uint8_t htype;
	uint8_t hlen;
	uint8_t hops;
	uint32_t xid;
	uint16_t secs;
	uint16_t flags;
	uint32_t ciaddr;
	uint32_t yiaddr;
	uint32_t siaddr;
	uint32_t giaddr;
	uint8_t chaddr[16];
	uint8_t sname[64];
	uint8_t file[128];
	uint32_t cookie;
	uint8_t options[DHCP_EXP_MESSAGE_DATA_SIZE];
};

#ifdef	ENABLE_FEATURE_BOOTP
struct ip_udp_header {
	struct iphdr ip;
	struct udphdr udp;
};
#endif	// ENABLE_FEATURE_BOOTP

struct udp_dhcp_packet_org {
	struct iphdr ip;
	struct udphdr udp;
	struct dhcpMessageOrg data;
};

struct udp_dhcp_packet {
	struct iphdr ip;
	struct udphdr udp;
	struct dhcpMessage data;
};

void init_header(struct dhcpMessage *packet, char type);
int get_packet(struct dhcpMessage *packet, int fd);
uint16_t checksum(void *addr, int count);
int raw_packet(struct dhcpMessage *payload, uint32_t source_ip, int source_port,
		   uint32_t dest_ip, int dest_port, uint8_t *dest_arp, int ifindex);
int kernel_packet(struct dhcpMessage *payload, uint32_t source_ip, int source_port,
		   uint32_t dest_ip, int dest_port);
#ifdef	ENABLE_FEATURE_BOOTP
int raw_bootp_packet(struct dhcpMessage *payload, uint32_t source_ip, int source_port,
		   uint32_t dest_ip, int dest_port, uint8_t *dest_arp, int ifindex);
#endif	// ENABLE_FEATURE_BOOTP


#endif
