/* 
   Handling of NTLM Authentication
   Copyright (C) 2003, Daniel Stenberg <daniel@haxx.se>
   Copyright (C) 2009, Kai Sommerfeld <kso@openoffice.org>

   This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Library General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Library General Public License for more details.

   You should have received a copy of the GNU Library General Public
   License along with this library; if not, write to the Free
   Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
   MA 02111-1307, USA

*/

/* NTLM details:
   
   http://davenport.sourceforge.net/ntlm.html
   http://www.innovation.ch/java/ntlm.html

*/

#include "ne_ntlm.h"

#ifdef HAVE_NTLM

#include "ne_string.h"

#ifdef HAVE_NTLMv2
#include <openssl/hmac.h>
#include "ne_utils.h"
#include "ne_request.h"
#include "ne_auth.h"

#define NTLM_HMAC_MD5_LEN     (16)
#define NTLMv2_BLOB_SIGNATURE "\x01\x01\x00\x00"
#define NTLMv2_BLOB_LEN       (44 -16 + ctx->target_info_len + 4)

#define NTLM_BUFSIZE 1024

#define IS_NTLMV2(ctx)  ((ctx->target_info != NULL) && (ctx->target_info_len > 0))

#endif /* HAVE_NTLMv2 */

typedef enum {
  NTLMSTATE_NONE,
  NTLMSTATE_TYPE1,
  NTLMSTATE_TYPE2,
  NTLMSTATE_TYPE3,
  NTLMSTATE_LAST
} NTLMState;

struct ne_ntlm_context_s {
  NTLMState state;
  unsigned char nonce[8];
	
#ifdef HAVE_NTLMv2
  void * target_info; /* TargetInfo received in the ntlm type-2 message */
  unsigned int target_info_len;
#endif
	
  char *user;
  char *passwd;
  char *requestToken;
};

typedef enum {
  NTLM_NONE, /* not a ntlm */
  NTLM_BAD,  /* an ntlm, but one we don't like */
  NTLM_FIRST, /* the first 401-reply we got with NTLM */
  NTLM_FINE, /* an ntlm we act on */

  NTLM_LAST  /* last entry in this enum, don't use */
} ntlm;

/* Flag bits definitions based on http://davenport.sourceforge.net/ntlm.html */

#define NTLMFLAG_NEGOTIATE_UNICODE               (1<<0)
/* Indicates that Unicode strings are supported for use in security buffer
   data. */

#define NTLMFLAG_NEGOTIATE_OEM                   (1<<1)
/* Indicates that OEM strings are supported for use in security buffer data. */

#define NTLMFLAG_REQUEST_TARGET                  (1<<2)
/* Requests that the server's authentication realm be included in the Type 2
   message. */

/* unknown (1<<3) */
#define NTLMFLAG_NEGOTIATE_SIGN                  (1<<4)
/* Specifies that authenticated communication between the client and server
   should carry a digital signature (message integrity). */

#define NTLMFLAG_NEGOTIATE_SEAL                  (1<<5)
/* Specifies that authenticated communication between the client and server
   should be encrypted (message confidentiality). */

#define NTLMFLAG_NEGOTIATE_DATAGRAM_STYLE        (1<<6)
/* unknown purpose */

#define NTLMFLAG_NEGOTIATE_LM_KEY                (1<<7)
/* Indicates that the LAN Manager session key should be used for signing and
   sealing authenticated communications. */

#define NTLMFLAG_NEGOTIATE_NETWARE               (1<<8)
/* unknown purpose */

#define NTLMFLAG_NEGOTIATE_NTLM_KEY              (1<<9)
/* Indicates that NTLM authentication is being used. */

/* unknown (1<<10) */
/* unknown (1<<11) */

#define NTLMFLAG_NEGOTIATE_DOMAIN_SUPPLIED       (1<<12)
/* Sent by the client in the Type 1 message to indicate that a desired
   authentication realm is included in the message. */

#define NTLMFLAG_NEGOTIATE_WORKSTATION_SUPPLIED  (1<<13)
/* Sent by the client in the Type 1 message to indicate that the client
   workstation's name is included in the message. */

#define NTLMFLAG_NEGOTIATE_LOCAL_CALL            (1<<14)
/* Sent by the server to indicate that the server and client are on the same
   machine. Implies that the client may use a pre-established local security
   context rather than responding to the challenge. */

#define NTLMFLAG_NEGOTIATE_ALWAYS_SIGN           (1<<15)
/* Indicates that authenticated communication between the client and server
   should be signed with a "dummy" signature. */

#define NTLMFLAG_TARGET_TYPE_DOMAIN              (1<<16)
/* Sent by the server in the Type 2 message to indicate that the target
   authentication realm is a domain. */

#define NTLMFLAG_TARGET_TYPE_SERVER              (1<<17)
/* Sent by the server in the Type 2 message to indicate that the target
   authentication realm is a server. */

#define NTLMFLAG_TARGET_TYPE_SHARE               (1<<18)
/* Sent by the server in the Type 2 message to indicate that the target
   authentication realm is a share. Presumably, this is for share-level
   authentication. Usage is unclear. */

#define NTLMFLAG_NEGOTIATE_NTLM2_KEY             (1<<19)
/* Indicates that the NTLM2 signing and sealing scheme should be used for
   protecting authenticated communications. */

#define NTLMFLAG_REQUEST_INIT_RESPONSE           (1<<20)
/* unknown purpose */

#define NTLMFLAG_REQUEST_ACCEPT_RESPONSE         (1<<21)
/* unknown purpose */

#define NTLMFLAG_REQUEST_NONNT_SESSION_KEY       (1<<22)
/* unknown purpose */

#define NTLMFLAG_NEGOTIATE_TARGET_INFO           (1<<23)
/* Sent by the server in the Type 2 message to indicate that it is including a
   Target Information block in the message. */

/* unknown (1<24) */
/* unknown (1<25) */
/* unknown (1<26) */
/* unknown (1<27) */
/* unknown (1<28) */

#define NTLMFLAG_NEGOTIATE_128                   (1<<29)
/* Indicates that 128-bit encryption is supported. */

#define NTLMFLAG_NEGOTIATE_KEY_EXCHANGE          (1<<30)
/* unknown purpose */

#define NTLMFLAG_NEGOTIATE_56                    (1<<31)
/* Indicates that 56-bit encryption is supported. */

#ifdef HAVE_OPENSSL
/* We need OpenSSL for the crypto lib to provide us with MD4 and DES */

/* -- WIN32 approved -- */
#include <stdio.h>
#include <string.h>
#include <stdarg.h>
#include <stdlib.h>
#include <ctype.h>

#include <openssl/des.h>
#include <openssl/md4.h>
#include <openssl/ssl.h>

#if OPENSSL_VERSION_NUMBER < 0x00907001L
#define DES_key_schedule des_key_schedule
#define DES_cblock des_cblock
#define DES_set_odd_parity des_set_odd_parity
#define DES_set_key des_set_key
#define DES_ecb_encrypt des_ecb_encrypt

/* This is how things were done in the old days */
#define DESKEY(x) x
#define DESKEYARG(x) x
#else
/* Modern version */
#define DESKEYARG(x) *x
#define DESKEY(x) &x
#endif

/* Define this to make the type-3 message include the NT response message */
#define USE_NTRESPONSES 1

#ifdef HAVE_NTLMv2

static void ntlm_print_flags(FILE *handle, unsigned long flags)
{
  if(flags & NTLMFLAG_NEGOTIATE_UNICODE)
    fprintf(handle, "NTLMFLAG_NEGOTIATE_UNICODE ");
  if(flags & NTLMFLAG_NEGOTIATE_OEM)
    fprintf(handle, "NTLMFLAG_NEGOTIATE_OEM ");
  if(flags & NTLMFLAG_REQUEST_TARGET)
    fprintf(handle, "NTLMFLAG_REQUEST_TARGET ");
  if(flags & (1<<3))
    fprintf(handle, "NTLMFLAG_UNKNOWN_3 ");
  if(flags & NTLMFLAG_NEGOTIATE_SIGN)
    fprintf(handle, "NTLMFLAG_NEGOTIATE_SIGN ");
  if(flags & NTLMFLAG_NEGOTIATE_SEAL)
    fprintf(handle, "NTLMFLAG_NEGOTIATE_SEAL ");
  if(flags & NTLMFLAG_NEGOTIATE_DATAGRAM_STYLE)
    fprintf(handle, "NTLMFLAG_NEGOTIATE_DATAGRAM_STYLE ");
  if(flags & NTLMFLAG_NEGOTIATE_LM_KEY)
    fprintf(handle, "NTLMFLAG_NEGOTIATE_LM_KEY ");
  if(flags & NTLMFLAG_NEGOTIATE_NETWARE)
    fprintf(handle, "NTLMFLAG_NEGOTIATE_NETWARE ");
  if(flags & NTLMFLAG_NEGOTIATE_NTLM_KEY)
    fprintf(handle, "NTLMFLAG_NEGOTIATE_NTLM_KEY ");
  if(flags & (1<<10))
    fprintf(handle, "NTLMFLAG_UNKNOWN_10 ");
  if(flags & NTLMFLAG_NEGOTIATE_DOMAIN_SUPPLIED)
    fprintf(handle, "NTLMFLAG_NEGOTIATE_DOMAIN_SUPPLIED ");
  if(flags & NTLMFLAG_NEGOTIATE_WORKSTATION_SUPPLIED)
    fprintf(handle, "NTLMFLAG_NEGOTIATE_WORKSTATION_SUPPLIED ");
  if(flags & NTLMFLAG_NEGOTIATE_LOCAL_CALL)
    fprintf(handle, "NTLMFLAG_NEGOTIATE_LOCAL_CALL ");
  if(flags & NTLMFLAG_NEGOTIATE_ALWAYS_SIGN)
    fprintf(handle, "NTLMFLAG_NEGOTIATE_ALWAYS_SIGN ");
  if(flags & NTLMFLAG_TARGET_TYPE_DOMAIN)
    fprintf(handle, "NTLMFLAG_TARGET_TYPE_DOMAIN ");
  if(flags & NTLMFLAG_TARGET_TYPE_SERVER)
    fprintf(handle, "NTLMFLAG_TARGET_TYPE_SERVER ");
  if(flags & NTLMFLAG_TARGET_TYPE_SHARE)
    fprintf(handle, "NTLMFLAG_TARGET_TYPE_SHARE ");
  if(flags & NTLMFLAG_NEGOTIATE_NTLM2_KEY)
    fprintf(handle, "NTLMFLAG_NEGOTIATE_NTLM2_KEY ");
  if(flags & NTLMFLAG_REQUEST_INIT_RESPONSE)
    fprintf(handle, "NTLMFLAG_REQUEST_INIT_RESPONSE ");
  if(flags & NTLMFLAG_REQUEST_ACCEPT_RESPONSE)
    fprintf(handle, "NTLMFLAG_REQUEST_ACCEPT_RESPONSE ");
  if(flags & NTLMFLAG_REQUEST_NONNT_SESSION_KEY)
    fprintf(handle, "NTLMFLAG_REQUEST_NONNT_SESSION_KEY ");
  if(flags & NTLMFLAG_NEGOTIATE_TARGET_INFO)
    fprintf(handle, "NTLMFLAG_NEGOTIATE_TARGET_INFO ");
  if(flags & (1<<24))
    fprintf(handle, "NTLMFLAG_UNKNOWN_24 ");
  if(flags & (1<<25))
    fprintf(handle, "NTLMFLAG_UNKNOWN_25 ");
  if(flags & (1<<26))
    fprintf(handle, "NTLMFLAG_UNKNOWN_26 ");
  if(flags & (1<<27))
    fprintf(handle, "NTLMFLAG_UNKNOWN_27 ");
  if(flags & (1<<28))
    fprintf(handle, "NTLMFLAG_UNKNOWN_28 ");
  if(flags & NTLMFLAG_NEGOTIATE_128)
    fprintf(handle, "NTLMFLAG_NEGOTIATE_128 ");
  if(flags & NTLMFLAG_NEGOTIATE_KEY_EXCHANGE)
    fprintf(handle, "NTLMFLAG_NEGOTIATE_KEY_EXCHANGE ");
  if(flags & NTLMFLAG_NEGOTIATE_56)
    fprintf(handle, "NTLMFLAG_NEGOTIATE_56 ");
}

static void ntlm_print_hex(FILE *handle, const char *buf, size_t len)
{
  const char *p = buf;
  (void)handle;

  fprintf(stderr, "0x");

  while(len-- > 0)
    fprintf(stderr, "%02x", (unsigned int)*p++);
}


/**
 * @brief readint_le()
 * This function converts from the little endian format used in
 * the incoming package to whatever endian format we're using
 * natively. Argument is a pointer to a 4 byte buffer.
 * 
 * @param buf Buffer to convert
 * 
 * @return unsigned int
 */
static unsigned int readint_le(unsigned char *buf)
{
  return ((unsigned int)buf[0]) | ((unsigned int)buf[1] << 8) |
    ((unsigned int)buf[2] << 16) | ((unsigned int)buf[3] << 24);
}


/**
 * @brief readshort_le()
 * This function converts from the little endian format used in the incoming
 * package to whatever endian format we're using natively. Argument is a
 * pointer to a 2 byte buffer.
 * 
 * @param buf Buffer to convert
 * 
 * @return unsigned int
 */
static unsigned int readshort_le(unsigned char *buf)
{
  return ((unsigned int)buf[0]) | ((unsigned int)buf[1] << 8);
}


static void ascii_to_unicode_le(unsigned char *dest, const char *src,
                                size_t srclen)
{
  size_t i;
  for(i = 0; i < srclen; i++) {
    dest[2 * i] = (unsigned char)src[i];
    dest[2 * i + 1] = '\0';
  }
}

static void ascii_uppercase_to_unicode_le(unsigned char *dest,
                                          const char *src, size_t srclen)
{
  size_t i;
  for(i = 0; i < srclen; i++) {
    dest[2 * i] = (unsigned char)(toupper(src[i]));
    dest[2 * i + 1] = '\0';
  }
}

static void write32_le(const int value, unsigned char *buffer)
{
  buffer[0] = (char)(value & 0x000000FF);
  buffer[1] = (char)((value & 0x0000FF00) >> 8);
  buffer[2] = (char)((value & 0x00FF0000) >> 16);
  buffer[3] = (char)((value & 0xFF000000) >> 24);
}

static void write64_le(const long long value, unsigned char *buffer)
{
  write32_le((int)value, buffer);
  write32_le((int)(value >> 32), buffer + 4);
}


/*
 * ntlm_decode_type2_target()
 *
 * This is used to decode the "target info" in the ntlm type-2 message
 * received.
 *
 * Parameters:
 *
 * ctx       [in]    - Pointer to the NTLM context
 * buffer    [in]    - The decoded base64 ntlm header of Type 2
 * size      [in]    - The input buffer size, atleast 32 bytes
 *
 * Returns NE_OK on success.
 */
static int ntlm_decode_type2_target(ne_ntlm_context *ctx,
                                    unsigned char *buffer,
                                    size_t size)
{
  unsigned int target_info_len      = 0;
  unsigned int target_info_offset   = 0;
  
  if (ctx->target_info)
  {
      ne_free(ctx->target_info);
      ctx->target_info = NULL;
  }  

  ctx->target_info_len = 0;

  if(size >= 48)
  {
    target_info_len = readshort_le(&buffer[40]);
    target_info_offset = readint_le(&buffer[44]);

    if(target_info_len > 0)
    {
      if(((target_info_offset + target_info_len) > size) || (target_info_offset < 48))
      {
        NE_DEBUG(NE_DBG_HTTPAUTH, "NTLM handshake failure (bad type-2 message): Target Info Offset Len is set incorrect by the peer\n");

        return NE_ERROR;
      }

      ctx->target_info = ne_malloc(target_info_len);
      
      memcpy(ctx->target_info, &buffer[target_info_offset], target_info_len);
      ctx->target_info_len = target_info_len;
    }
  }

  return NE_OK;
}


/* This returns the HMAC MD5 digest */
static int hmac_md5(const unsigned char *key,
                    unsigned int keylen,
                    const unsigned char *data,
                    unsigned int datalen,
                    unsigned char *output)
{
  unsigned int output_len = 0;

  if (!HMAC(EVP_md5(), key, keylen, data, datalen, output, &output_len))
  {
      NE_DEBUG(NE_DBG_HTTPAUTH, "HMAC() MD5 method returned null\n");

      return NE_ERROR;
  }

  return NE_OK;
}


static int mk_ntlmv2_hash(const char *user, size_t userlen,
                          const char *domain, size_t domlen,
                          unsigned char *ntlmhash,
                          unsigned char *ntlmv2hash)
{
  int res = NE_OK;
  
  /* Unicode representation */
  size_t identity_len = (userlen + domlen) * 2;
  unsigned char *identity = ne_malloc(identity_len);
  
  ascii_uppercase_to_unicode_le(identity, user, userlen);
  ascii_to_unicode_le(identity + (userlen << 1), domain, domlen);

  res = hmac_md5(ntlmhash, 16, identity, identity_len, ntlmv2hash);

  ne_free(identity);

  return res;
}


/*
 * mk_ntlmv2_resp()
 *
 * This creates the NTLMv2 response as set in the ntlm type-3 message.
 *
 * Parameters:
 *
 * ntlmv2hash       [in] - The ntlmv2 hash (16 bytes)
 * challenge_client [in] - The client nonce (8 bytes)
 * ctx              [in] - NTLM context structure
 * ntresp           [out] - The address where a pointer to newly allocated
 *                         memory holding the NTLMv2 response.
 * ntresp_len      [out] - The length of the output message.
 *
 * Returns NE_OK on success.
 */
static int mk_ntlmv2_resp(unsigned char *ntlmv2hash,
                          unsigned char *challenge_client,
                          ne_ntlm_context *ctx,
                          unsigned char **ntresp,
                          unsigned int *ntresp_len)
{
/* NTLMv2 response structure :
------------------------------------------------------------------------------
0     HMAC MD5         16 bytes
------BLOB--------------------------------------------------------------------
16    Signature        0x01010000
20    Reserved         long (0x00000000)
24    Timestamp        LE, 64-bit signed value representing the number of
                       tenths of a microsecond since January 1, 1601.
32    Client Nonce     8 bytes
40    Unknown          4 bytes
44    Target Info      N bytes (from the type-2 message)
44+N  Unknown          4 bytes
------------------------------------------------------------------------------
*/

  unsigned int len = 0;
  unsigned char *ptr = NULL;
  unsigned char hmac_output[NTLM_HMAC_MD5_LEN];
  long long tw;
  unsigned int res = NE_OK;

  /* Calculate the timestamp */
#if defined(DEBUGBUILD)
  tw = 11644473600ULL * 10000000ULL;
#else
  tw = ((long long)time(NULL) + 11644473600ULL) * 10000000ULL;
#endif

  /* Calculate the response len */
  len = NTLM_HMAC_MD5_LEN + NTLMv2_BLOB_LEN;

  /* Allocate the response */
  ptr = ne_malloc(len);
 
  memset(ptr, 0, len);

  /* Create the BLOB structure */
  snprintf((char *)ptr + NTLM_HMAC_MD5_LEN, NTLMv2_BLOB_LEN,
           "%c%c%c%c%c%c%c%c", 0x01, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00);

  /* Add the timestamp */
  write64_le(tw, ptr + 24);

  /* Add the client challenge */
  memcpy(ptr + 32, challenge_client, 8);

  /* Add the Target Info */
  memcpy(ptr + 44, ctx->target_info, ctx->target_info_len);

  /* Concatenate the Type 2 challenge with the BLOB and do HMAC MD5 */
  memcpy(ptr + 8, &ctx->nonce[0], 8);
  
  /* Perform HMAC MD5 on the server challenge + blob using NTLMv2 hash as the key */
  res = hmac_md5(ntlmv2hash, NTLM_HMAC_MD5_LEN, ptr + 8, NTLMv2_BLOB_LEN + 8, hmac_output);

  if(res != NE_OK)
  {
    ne_free(ptr);
    return res;
  }

  /* Concatenate the HMAC MD5 output  with the BLOB */
  memcpy(ptr, hmac_output, NTLM_HMAC_MD5_LEN);

  /* Return the response */
  *ntresp = ptr;
  *ntresp_len = len;

  return res;
}

/*
 * mk_lmv2_resp()
 *
 * This creates the LMv2 response as used in the ntlm type-3 message.
 *
 * Parameters:
 *
 * ntlmv2hash        [in] - The ntlmv2 hash (16 bytes)
 * challenge_client  [in] - The client nonce (8 bytes)
 * challenge_client  [in] - The server challenge (8 bytes)
 * lmresp           [out] - The LMv2 response (24 bytes)
 *
 * Returns NE_OK on success.
 */
static unsigned int mk_lmv2_resp(unsigned char *ntlmv2hash,
                                 unsigned char *challenge_client,
                                 unsigned char *challenge_server,
                                 unsigned char *lmresp)
{
  unsigned char data[16];
  unsigned char hmac_output[16];
  unsigned int res = NE_OK;

  memcpy(&data[0], challenge_server, 8);
  memcpy(&data[8], challenge_client, 8);

  res = hmac_md5(ntlmv2hash, 16, &data[0], 16, hmac_output);

  if(res != NE_OK)
  {
    return res;
  }

  /* Concatenate the HMAC MD5 output with the client nonce */
  memcpy(lmresp, hmac_output, 16);
  memcpy(lmresp+16, challenge_client, 8);

  return res;
}
#endif /* HAVE_NTLMv2 */

/*
  (*) = A "security buffer" is a triplet consisting of two shorts and one
  long:

  1. a 'short' containing the length of the buffer in bytes
  2. a 'short' containing the allocated space for the buffer in bytes
  3. a 'long' containing the offset to the start of the buffer from the
     beginning of the NTLM message, in bytes.
*/

static ntlm ne_input_ntlm(ne_ntlm_context *ctx,
			  const char *responseToken)
{
  if(responseToken) {
    /* We got a type-2 message here:

       Index   Description         Content
       0       NTLMSSP Signature   Null-terminated ASCII "NTLMSSP"
                                   (0x4e544c4d53535000)
       8       NTLM Message Type   long (0x02000000)
       12      Target Name         security buffer(*)
       20      Flags               long
       24      Challenge           8 bytes
       (32)    Context (optional)  8 bytes (two consecutive longs)
       (40)    Target Information  (optional) security buffer(*)
       32 (48) start of data block
    */
    unsigned char * buffer = NULL;

    int size = ne_unbase64(responseToken, &buffer);

    ctx->state = NTLMSTATE_TYPE2; /* we got a type-2 */

    if(size >= 48)
      /* the nonce of interest is index [24 .. 31], 8 bytes */
      memcpy(ctx->nonce, &buffer[24], 8);

    /* at index decimal 20, there's a 32bit NTLM flag field */
      
#ifdef HAVE_NTLMv2

    /*
     * Check for a Target Info security buffer in the
     * NTLMSSP_CHALLENGE (Type 2) message, and decode it
     * if present
     */
    unsigned long int flags = 0;

     if(size >= 48)
     {
       flags = readint_le(&buffer[20]);     
     }

     if(flags & NTLMFLAG_NEGOTIATE_TARGET_INFO)
     {
       int error = ntlm_decode_type2_target(ctx, buffer, size);

       if(error)
       {
         if (buffer)
           ne_free(buffer); 
                 
         NE_DEBUG(NE_DBG_HTTPAUTH, "ne_input_ntlm: NTLM handshake failure (bad type-2 message)\n");

         return NTLM_BAD;
       }
     }
        
#endif /* HAVE_NTLMv2 */

    if (buffer) ne_free(buffer); 
  }
  else {
    if(ctx->state >= NTLMSTATE_TYPE1)
      return NTLM_BAD;

    ctx->state = NTLMSTATE_TYPE1; /* we should sent away a type-1 */
  }
  return NTLM_FINE;
}

/*
 * Turns a 56 bit key into the 64 bit, odd parity key and sets the key.  The
 * key schedule ks is also set.
 */
static void setup_des_key(unsigned char *key_56,
                          DES_key_schedule DESKEYARG(ks))
{
  DES_cblock key;

  key[0] = key_56[0];
  key[1] = ((key_56[0] << 7) & 0xFF) | (key_56[1] >> 1);
  key[2] = ((key_56[1] << 6) & 0xFF) | (key_56[2] >> 2);
  key[3] = ((key_56[2] << 5) & 0xFF) | (key_56[3] >> 3);
  key[4] = ((key_56[3] << 4) & 0xFF) | (key_56[4] >> 4);
  key[5] = ((key_56[4] << 3) & 0xFF) | (key_56[5] >> 5);
  key[6] = ((key_56[5] << 2) & 0xFF) | (key_56[6] >> 6);
  key[7] =  (key_56[6] << 1) & 0xFF;

  DES_set_odd_parity(&key);
  DES_set_key(&key, ks);
}

 /*
  * takes a 21 byte array and treats it as 3 56-bit DES keys. The
  * 8 byte plaintext is encrypted with each key and the resulting 24
  * bytes are stored in the results array.
  */
static void calc_resp(unsigned char *keys,
                      unsigned char *plaintext,
                      unsigned char *results)
{
  DES_key_schedule ks;

  setup_des_key(keys, DESKEY(ks));
  DES_ecb_encrypt((DES_cblock*) plaintext, (DES_cblock*) results,
                  DESKEY(ks), DES_ENCRYPT);

  setup_des_key(keys+7, DESKEY(ks));
  DES_ecb_encrypt((DES_cblock*) plaintext, (DES_cblock*) (results+8),
                  DESKEY(ks), DES_ENCRYPT);

  setup_des_key(keys+14, DESKEY(ks));
  DES_ecb_encrypt((DES_cblock*) plaintext, (DES_cblock*) (results+16),
                  DESKEY(ks), DES_ENCRYPT);
}

/*
 * Set up lanmanager and nt hashed passwords
 */
static void mkhash(char *password,
                   unsigned char *nonce,  /* 8 bytes */
                   unsigned char *lmresp  /* must fit 0x18 bytes */
#ifdef HAVE_NTLMv2                  
                   , unsigned char **ntlmhash /* must fit 16 bytes */
#endif
#ifdef USE_NTRESPONSES
                   , unsigned char *ntresp  /* must fit 0x18 bytes */
#endif
  )
{
  unsigned char lmbuffer[21];
#ifdef USE_NTRESPONSES
  unsigned char ntbuffer[21];
#endif
  unsigned char *pw;
  static const unsigned char magic[] = {
    0x4B, 0x47, 0x53, 0x21, 0x40, 0x23, 0x24, 0x25
  };
  int i;
  int len = strlen(password);

  /* make it fit at least 14 bytes */
  pw = ne_malloc(len<7?14:len*2);
  if(!pw)
    return; /* this will lead to a badly generated package */

  if (len > 14)
    len = 14;
  
  for (i=0; i<len; i++)
    pw[i] = toupper(password[i]);

  for (; i<14; i++)
    pw[i] = 0;

  {
    /* create LanManager hashed password */
    DES_key_schedule ks;

    setup_des_key(pw, DESKEY(ks));
    DES_ecb_encrypt((DES_cblock *)magic, (DES_cblock *)lmbuffer,
                    DESKEY(ks), DES_ENCRYPT);
  
    setup_des_key(pw+7, DESKEY(ks));
    DES_ecb_encrypt((DES_cblock *)magic, (DES_cblock *)(lmbuffer+8),
                    DESKEY(ks), DES_ENCRYPT);

    memset(lmbuffer+16, 0, 5);
  }
  /* create LM responses */
  calc_resp(lmbuffer, nonce, lmresp);

#ifdef USE_NTRESPONSES
  {
    /* create NT hashed password */
    MD4_CTX md4;

    len = strlen(password);

    for (i=0; i<len; i++) {
      pw[2*i]   = password[i];
      pw[2*i+1] = 0;
    }

    MD4_Init(&md4);
    MD4_Update(&md4, pw, 2*len);
    MD4_Final(ntbuffer, &md4);

    memset(ntbuffer+16, 0, 5);
  }

  calc_resp(ntbuffer, nonce, ntresp);
#endif

#ifdef HAVE_NTLMv2
    /* Populate the ntlmhash buffer output arg
     * for use in other functions
     * (e.g. calculating ntlmv2 hash)
     */
    memcpy(ntlmhash, ntbuffer, 16);
#endif

  ne_free(pw);
}

#define SHORTPAIR(x) ((x) & 0xff), ((x) >> 8)
#define LONGQUARTET(x) ((x) & 0xff), (((x) >> 8)&0xff), \
  (((x) >>16)&0xff), ((x)>>24)

/* this is for creating ntlm header output */
static int ne_output_ntlm(ne_ntlm_context *ctx)
{
  const char *domain=""; /* empty */
  const char *host=""; /* empty */
  int domlen=strlen(domain);
  int hostlen = strlen(host);
  int hostoff; /* host name offset */
  int domoff;  /* domain name offset */
  int size;
#ifdef HAVE_NTLMv2
  unsigned char ntlmbuf[NTLM_BUFSIZE];  
#else
  unsigned char ntlmbuf[256]; /* enough, unless the host/domain is very long */
#endif

  if(!ctx->user || !ctx->passwd)
    /* no user, no auth */
    return 0; /* OK */
  
  switch(ctx->state) {
  case NTLMSTATE_TYPE1:
  default: /* for the weird cases we (re)start here */
    hostoff = 32;
    domoff = hostoff + hostlen;
    
    /* Create and send a type-1 message:

    Index Description          Content
    0     NTLMSSP Signature    Null-terminated ASCII "NTLMSSP"
                               (0x4e544c4d53535000)
    8     NTLM Message Type    long (0x01000000)
    12    Flags                long
    16    Supplied Domain      security buffer(*)
    24    Supplied Workstation security buffer(*)
    32    start of data block

    */

    ne_snprintf((char *)ntlmbuf, sizeof(ntlmbuf), "NTLMSSP%c"
             "\x01%c%c%c" /* 32-bit type = 1 */
             "%c%c%c%c"   /* 32-bit NTLM flag field */
             "%c%c"  /* domain length */
             "%c%c"  /* domain allocated space */
             "%c%c"  /* domain name offset */
             "%c%c"  /* 2 zeroes */
             "%c%c"  /* host length */
             "%c%c"  /* host allocated space */
             "%c%c"  /* host name offset */
             "%c%c"  /* 2 zeroes */
             "%s"   /* host name */
             "%s",  /* domain string */
             0,     /* trailing zero */
             0,0,0, /* part of type-1 long */

             LONGQUARTET(
               NTLMFLAG_NEGOTIATE_OEM|      /*   2 */
               NTLMFLAG_NEGOTIATE_NTLM_KEY  /* 200 */
               /* equals 0x0202 */
#ifdef HAVE_NTLMv2
               /* 
                * Need to set the NTLMFLAG_REQUEST_TARGET flag in the
                * NTLMSSP_NEGOTIATE (Type 1) message to ensure the
                * Target Info security buffer is included in the
                * NTLMSSP_CHALLENGE (Type 2) message.
                * 
                * Setting the NTLMFLAG_NEGOTIATE_TARGET_INFO flag in the
                * NTLMSSP_NEGOTIATE (Type 1) message doesn't stimulate that.
                */
               | NTLMFLAG_REQUEST_TARGET /* 0x4 */               
               /* equals 0x206 */
#endif
               ),
             SHORTPAIR(domlen),
             SHORTPAIR(domlen),
             SHORTPAIR(domoff),
             0,0,
             SHORTPAIR(hostlen),
             SHORTPAIR(hostlen),
             SHORTPAIR(hostoff),
             0,0,
             host, domain);

    /* initial packet length */
    size = 32 + hostlen + domlen;

    /* now keeper of the base64 encoded package size */
    if (ctx->requestToken) ne_free(ctx->requestToken);
    ctx->requestToken = ne_base64(ntlmbuf, size);

    break;
    
  case NTLMSTATE_TYPE2:
    /* We received the type-2 already, create a type-3 message:

    Index   Description            Content
    0       NTLMSSP Signature      Null-terminated ASCII "NTLMSSP"
                                   (0x4e544c4d53535000)
    8       NTLM Message Type      long (0x03000000)
    12      LM/LMv2 Response       security buffer(*)
    20      NTLM/NTLMv2 Response   security buffer(*)
    28      Domain Name            security buffer(*)
    36      User Name              security buffer(*)
    44      Workstation Name       security buffer(*)
    (52)    Session Key (optional) security buffer(*)
    (60)    Flags (optional)       long
    52 (64) start of data block

    */
  
  {
    int lmrespoff;
    int ntrespoff;
    int useroff;
    unsigned char lmresp[0x18]; /* fixed-size */
#ifdef USE_NTRESPONSES
    unsigned char ntresp[0x18]; /* fixed-size */
#endif

#ifdef HAVE_NTLMv2  
    unsigned char *ptr_ntresp = &ntresp[0];
    unsigned char *ntlmv2resp = NULL;
#endif

     int ntresplen = 24;

#ifdef HAVE_NTLMv2
   
    unsigned char ntlmhash[16];
    unsigned char ntlmv2hash[16];
    
    memset(ntlmhash, 0, 16 * sizeof(unsigned char));
    memset(ntlmv2hash, 0, 16 * sizeof(unsigned char));
#endif
  	
    const char *user;
    int userlen;

    user = strchr(ctx->user, '\\');
    if(!user)
      user = strchr(ctx->user, '/');

    if (user) {
      domain = ctx->user;
      domlen = user - domain;
      user++;
    }
    else
      user = ctx->user;
    userlen = strlen(user);

    mkhash(ctx->passwd, &ctx->nonce[0], lmresp
#ifdef HAVE_NTLMv2
           /* 
            * Need to reuse the NTLMv1 hash  
            * for obtaining the NTLMv2 hash
            */
           , (unsigned char **) &ntlmhash
#endif
#ifdef USE_NTRESPONSES
           , ntresp
#endif
      );

#ifdef HAVE_NTLMv2

    if (IS_NTLMV2(ctx))
    {   
        NE_DEBUG(NE_DBG_HTTPAUTH, "ne_output_ntlm(): using NTLMv2 authentication\n");
             
        /* Create a client nonce */     
        unsigned char challenge_client[8];
        memset(challenge_client, 0, 8 * sizeof(unsigned char));

        char *nonce_ptr = get_cnonce();
        if (nonce_ptr) 
        {
            memcpy(challenge_client, (unsigned char *)nonce_ptr, 8);
            ne_free(nonce_ptr);           
        }
        else
        {
            NE_DEBUG(NE_DBG_HTTPAUTH, "ne_output_ntlm(): ERROR creating client challenge\n");
            return -1;
        }
        
        /* Create the NTLMv2 hash */
        if (mk_ntlmv2_hash(user, userlen, domain, domlen, ntlmhash, ntlmv2hash) != NE_OK)
        {
            NE_DEBUG(NE_DBG_HTTPAUTH, "ne_output_ntlm(): ERROR NTLMv2 hash creation failed\n");
            return -1;
        }
      
        /* Create the LMv2 response */
        if (mk_lmv2_resp(ntlmv2hash, challenge_client, ctx->nonce, lmresp) != NE_OK)
        {
            NE_DEBUG(NE_DBG_HTTPAUTH, "ne_output_ntlm(): ERROR LMv2 response creation failed\n");
            return -1;
        }
        
        /* Create the NTLMv2 response */
        if (mk_ntlmv2_resp(ntlmv2hash, challenge_client, ctx, &ntlmv2resp, &ntresplen))
        {
             NE_DEBUG(NE_DBG_HTTPAUTH, "ne_output_ntlm(): ERROR NTLMv2 response creation failed\n");
             return -1;
       }

        ptr_ntresp = ntlmv2resp;              
    }    

#endif

    domoff = 64; /* always */
    useroff = domoff + domlen;
    hostoff = useroff + userlen;
    lmrespoff = hostoff + hostlen;
    ntrespoff = lmrespoff + 0x18;

    /* Create the big type-3 message binary blob */
    size = ne_snprintf((char *)ntlmbuf, sizeof(ntlmbuf),
                    "NTLMSSP%c"
                    "\x03%c%c%c" /* type-3, 32 bits */

                    "%c%c%c%c" /* LanManager length + allocated space */
                    "%c%c" /* LanManager offset */
                    "%c%c" /* 2 zeroes */

                    "%c%c" /* NT-response length */
                    "%c%c" /* NT-response allocated space */
                    "%c%c" /* NT-response offset */
                    "%c%c" /* 2 zeroes */
                    
                    "%c%c"  /* domain length */
                    "%c%c"  /* domain allocated space */
                    "%c%c"  /* domain name offset */
                    "%c%c"  /* 2 zeroes */
                    
                    "%c%c"  /* user length */
                    "%c%c"  /* user allocated space */
                    "%c%c"  /* user offset */
                    "%c%c"  /* 2 zeroes */
                    
                    "%c%c"  /* host length */
                    "%c%c"  /* host allocated space */
                    "%c%c"  /* host offset */
                    "%c%c%c%c%c%c"  /* 6 zeroes */
                    
                    "\xff\xff"  /* message length */
                    "%c%c"  /* 2 zeroes */
                    
                    "\x01\x82" /* flags */
                    "%c%c"  /* 2 zeroes */

                    /* domain string */
                    /* user string */
                    /* host string */
                    /* LanManager response */
                    /* NT response */
                    ,
                    0, /* zero termination */
                    0,0,0, /* type-3 long, the 24 upper bits */

                    SHORTPAIR(0x18),  /* LanManager response length, twice */
                    SHORTPAIR(0x18),
                    SHORTPAIR(lmrespoff),
                    0x0, 0x0,
                    
#ifdef USE_NTRESPONSES
                    SHORTPAIR(ntresplen),  /* NT-response length, twice */
                    SHORTPAIR(ntresplen),
#else
                    0x0, 0x0,
                    0x0, 0x0,
#endif
                    SHORTPAIR(ntrespoff),
                    0x0, 0x0,

                    SHORTPAIR(domlen),
                    SHORTPAIR(domlen),
                    SHORTPAIR(domoff),
                    0x0, 0x0,

                    SHORTPAIR(userlen),
                    SHORTPAIR(userlen),
                    SHORTPAIR(useroff),
                    0x0, 0x0,
                    
                    SHORTPAIR(hostlen),
                    SHORTPAIR(hostlen),
                    SHORTPAIR(hostoff),
                    0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
             
                    0x0, 0x0,

                    0x0, 0x0);

    /* size is now 64 */
    size=64;
    ntlmbuf[62]=ntlmbuf[63]=0;

    /* Make sure that the user and domain strings fit in the target buffer
       before we copy them there. */
    if((size_t)size + userlen + domlen >= sizeof(ntlmbuf)) {
      return -1;
    }

    memcpy(&ntlmbuf[size], domain, domlen);
    size += domlen;

    memcpy(&ntlmbuf[size], user, userlen);
    size += userlen;

    /* we append the binary hashes to the end of the blob */
    if(size < ((int)sizeof(ntlmbuf) - 0x18)) {
      memcpy(&ntlmbuf[size], lmresp, 0x18);
      size += 0x18;
    }

#ifdef USE_NTRESPONSES

#ifdef HAVE_NTLMv2
    if(size < ((int)sizeof(ntlmbuf) - ntresplen)) {
      memcpy(&ntlmbuf[size], ptr_ntresp, ntresplen);
      size += ntresplen; 
    }
#else
    if(size < ((int)sizeof(ntlmbuf) - 0x18)) {      
      memcpy(&ntlmbuf[size], ntresp, 0x18);
      size += 0x18;
    }
#endif /* HAVE_NTLMv2 */
    	
#endif

    ntlmbuf[56] = size & 0xff;
    ntlmbuf[57] = size >> 8;

    /* convert the binary blob into base64 */
    ctx->requestToken = ne_base64(ntlmbuf, size);

    ctx->state = NTLMSTATE_TYPE3; /* we sent a type-3 */

#ifdef HAVE_NTLMv2

    if (IS_NTLMV2(ctx))
    {
        /* Free the dynamically allocated ntlmv2resp buffer */
        if (ptr_ntresp)
        {
            ne_free(ptr_ntresp);

            ptr_ntresp = ntlmv2resp = NULL;
        }

        /* Free the dynamically allocated Target Info security buffer */
        if (ctx->target_info) 
        {        
            ne_free(ctx->target_info);

            ctx->target_info = NULL;
            ctx->target_info_len = 0;
        }
    }

#endif

  }
  break;

  case NTLMSTATE_TYPE3:
    /* connection is already authenticated,
     * don't send a header in future requests */
    if (ctx->requestToken) ne_free(ctx->requestToken);
    ctx->requestToken = NULL;
    break;
  }

  return 0; /* OK */
}

ne_ntlm_context *ne__ntlm_create_context(const char *userName, const char *password)
{
    ne_ntlm_context *ctx = ne_calloc(sizeof(ne_ntlm_context));

    ctx->state = NTLMSTATE_NONE;
    ctx->user = ne_strdup(userName);
    ctx->passwd = ne_strdup(password);
    
    return ctx;
}

void ne__ntlm_destroy_context(ne_ntlm_context *context)
{
    if (context->user)
        ne_free(context->user);
    
    if (context->passwd)
        ne_free(context->passwd);
    
    if (context->requestToken)
        ne_free(context->requestToken);
    
    ne_free(context);
}

int ne__ntlm_authenticate(ne_ntlm_context *context, const char *responseToken)
{
    if (context == NULL) {
	return -1;
    } else {
        if (!responseToken && (context->state == NTLMSTATE_TYPE3))
            context->state = NTLMSTATE_NONE;

        if (context->state <= NTLMSTATE_TYPE3) {
	  ntlm ntlmstatus = ne_input_ntlm(context, responseToken);

	  if (ntlmstatus != NTLM_FINE) { 
	    return -1;
	  }
	}
    }
    return ne_output_ntlm(context);
}

char *ne__ntlm_getRequestToken(ne_ntlm_context *context)
{
    char *ret;

    if (context == NULL || !context->requestToken) {
	return NULL;
    }

    ret = ne_strdup(context->requestToken);
    ne_free(context->requestToken);
    context->requestToken = NULL;
    return ret;
}

#endif /* HAVE_OPENSSL */
#endif /* HAVE_NTLM */
